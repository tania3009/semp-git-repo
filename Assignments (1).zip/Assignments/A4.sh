mv `find ./demo/ ! -empty -type f -exec md5sum {} + | sort | uniq -w32 -dD | awk '{print $2}' | head -n -1` ./demo/sample/
